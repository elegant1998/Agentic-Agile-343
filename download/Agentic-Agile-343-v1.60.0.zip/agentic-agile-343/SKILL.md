---
name: agentic-agile-343
description: "Agentic Agile 3-4-3：AI 原生人机协同研发操作系统的最小运行内核。用于在意图、约束、编排、执行、验证、证据和遥测之间建立可治理、可停止、可恢复、可追溯的工程闭环。面对既有项目、风险、变更、Bug、验证或发布请求时，先识别边界与责任，再调用最小必要能力；不得自动签署、授权、批准或执行不可逆操作。"
metadata:
  display_name: "Agentic Agile 343"
  version: "1.60.0"
  author: "王立杰-无敌哥"
  created: "2025-07-20"
---

# Agentic Agile 3-4-3

Agentic Agile 不是给旧流程增加一个 AI 工具，而是把人员、组织、流程和工具重构为 AI 时代的人机协同研发操作系统：以意图为方向，以约束为边界，以 Agent 为执行能力，以证据支持裁决，以遥测推动持续改进。

3-4-3 是这个操作系统的最小运行内核：3 个超级角色（IO、OA、AS），4 个动态工件（意图图谱、意图契约、约束矩阵、证据包），3 大自治机制（意图注入、对抗自净化、人类异常裁决）。SCOPE-V 是持续运行的控制面，不是线性瀑布流程。

## 工作协议

收到请求后，按以下顺序行动：

1. 判断任务类型、影响范围、风险、授权人和不可逆边界。
2. 先建立必要的意图、约束、变更围栏和 Preserve 基线，再实现。
3. 只在授权范围内执行；用独立证据验证，用遥测反馈系统。
4. 对未知、越界、证据不足、签署、批准、生产写入或其他不可逆动作停止并交人裁决。

用户字面意思不自动等于实现规格。遇到歧义、过宽授权、不可验证目标或与系统方向冲突时，先校准，说明假设，并提出最小必要问题。

## 自然语言路由

用户不需要记忆 CLI 或内部编号。按最具体的信号选择最小入口：

| 用户意图 | 路由 | 第一动作 |
|---|---|---|
| 既有项目先看看再改 | `PROJECT_RECON` | 只读建立 Baseline、Preserve、Unknown |
| 评估风险或初始化治理 | `RISK_INIT` | 生成 dry-run 计划，信息不足保留 Unknown |
| 分析某文件的影响范围 | `TASK_RECON` | 发现依赖、引用、测试和候选关系 |
| 本次只允许改指定文件 | `CHANGE_ENVELOPE` | 检查或生成 DRAFT 变更围栏 |
| 没有测试，先固定现有行为 | `CHARACTERIZE` | 规划并确认 Preserve 特征基线 |
| 安全修改既有功能 | `SAFE_CHANGE` | 编排 plan → prepare → verify → close |
| Bug、缺陷或回归 | `BUG` | 先找父任务并取得真实 RED，再修复 |
| 设计多层验证或检查证据独立性 | `VERIFICATION_PLAN` | 生成 DRAFT proof obligations |
| 生成证据包并完成任务 | `EVIDENCE_FINALIZE` | 在 Prove 后收口 Evidence 与 Telemetry |
| 准备发布、检查制品或记录回滚 | `RELEASE_MANIFEST` | 生成并核对携证发布清单 |
| 门禁误报或治理规则缺陷 | `MAINTENANCE` | 先判断是否满足维护通道准入 |

多个信号同时出现时，门禁缺陷优先走 `MAINTENANCE`，异常行为优先走 `BUG`，具体文件优先走 `TASK_RECON`。`CHANGE_ENVELOPE` 和 `CHARACTERIZE` 是 `SAFE_CHANGE` 的保护前置，不是扩大授权的方式。

## 硬边界

- 既有项目先 Recon；Recon 是只读事实发现，不是修改授权。
- Fact、Candidate、Unknown 必须分层；候选关系不得冒充事实，未知不得自动降级。
- 变更只能发生在已确认的 Change Envelope 内；Agent 不得自行扩大围栏、改为 `AUTHORIZED` 或代替 IO 签署。
- Preserve 需要 IO 或既有测试确认；特征基线只能证明既有行为，不替代验收标准。
- `MUST` 约束失败、证据缺失、证据同源、证据过期、AI 独证或 AI 代签均不得 PASS。
- 不自动签署、批准、发布、部署、打 Tag、push、修改权限或写入生产环境。
- 不以“测试全绿”单独宣称完成；完成必须能回溯到契约、验证、Evidence 和 Telemetry。
- 契约签署后不可静默改写；任务完成状态由合格事实派生，不由 Agent 自行宣告。
- 每次执行都要披露关键假设、未验证项、失败原因和下一步人类决策。

## 最小闭环

`Recon → Specify → Constrain → Orchestrate → Prove ⇄ Evolve → Verify → Evidence / Telemetry`

这是一个可暂停、可恢复、可回溯的控制循环。`Prove` 证明实现，`Evidence` 支持裁决，`Telemetry` 反馈系统；任一收口失败都保持 `BLOCKED`，不能伪装成完成。

## 按需加载

先只读取本文件，再按当前路由读取一个最小参考文件。不要批量读取全部 `references/`、`templates/` 或 `scripts/`。

| 需要处理 | 按需读取 |
|---|---|
| 话术识别、路由冲突、Bug 细则 | `references/natural_language_routing.md` |
| Recon、Change Envelope、Preserve、安全变更、Bug | `references/task_recon.md` |
| 多层验证、独立性、非二元裁决 | `references/verification_planning.md` |
| Evidence、Telemetry 收口 | `references/telemetry_collection.md` |
| 发布清单、制品绑定、回滚事实 | `references/release_manifest.md` |
| 门禁维护通道 | `references/maintenance_channel.md` |
| 批判性思考、Grill-Me、问题校准 | `references/critical_thinking.md` |
| 多人多模块、跨工具契约 | `references/multi_module.md` |
| 上下文、Harness、Loop Graph、SCOPE-V | 对应名称的 `references/*.md` |

只有在路由需要生成工件时读取对应模板；只有在需要执行或验证时读取对应脚本。模板和脚本是实现资源，不是入口必读内容。

## 执行入口

命令仅用于编排，不能替代授权：

```bash
python scripts/cli.py init --project-dir .
python scripts/cli.py recon task --task T-XXX --target <path> --project-dir .
python scripts/cli.py change plan --task T-XXX --target <path> --project-dir .
python scripts/cli.py change verify --task T-XXX --project-dir .
python scripts/cli.py release plan --project-dir .
```

需要具体参数、状态转换、模板字段或异常处理时，再读取对应 reference；不要凭记忆补全治理事实。

## 关于作者

王立杰（无敌哥），AI 治理架构师、研发效能顾问，《敏捷无敌》《京东敏捷实践指南》作者。

- 官网：<http://agentic.iloveagile.me/about>
- 微信：`iloveagile` · Email：3433839@qq.com
- 在线课程：<http://agentic.iloveagile.me/>
