# 关于codebase-memory-mcp和iwe双地图的构建与git 管理规则



Q: 如果某个 地图  过期、损坏、查询失败，是否应该提示相应建议操作，而非仅仅说unknown? 否则一旦不提示，用户可能也不能觉察；。。。另外地图是project 共享的，也就是多人共享的，那就只能靠git来同步了吧？用户不update，也是没办法的；但是recon后的新map,理论上应该是用户通过git PR给所有人的！这种冲突的概率有多高？git能处理吗？



A: 是的，不能只输出 `Unknown`。必须同时给出**可执行的修复建议**，否则渐进增强会变成静默降级，用户很难发现上下文质量已经下降。

**故障处理**

建议每个 Provider 输出统一诊断：

```
provider: IWE
status: stale
reason: SOURCE_REVISION_MISMATCH
impact: Document Map 未注入，当前降级为 L1
recommended_action:
  command: iwe normalize
  description: 在当前项目根目录刷新 Document Map
  automatic: false
```

不同情况分别处理：

| 状态                  | 行为                     | 建议                             |
| --------------------- | ------------------------ | -------------------------------- |
| `STALE`               | 不作为当前事实注入       | 拉取最新 Git、刷新地图           |
| `DAMAGED`             | 拒绝读取，保留另一张地图 | 重建地图，检查损坏文件           |
| `QUERY_FAILED`        | 本次回退                 | 检查 CLI、权限、项目索引状态     |
| `REVISION_MISMATCH`   | 不消费旧 Code Map        | 先同步代码，再重新索引           |
| `SCHEMA_INCOMPATIBLE` | fail closed              | 升级 Provider Adapter 或重新导出 |
| `CONFLICTED`          | 冲突项不进入可信上下文   | 人工解决来源文档或稳定 ID 冲突   |

建议同时提供：

- `impact`：这次降到了 L0、L1 还是 L2
- `recommended_action`：具体怎么恢复
- `command`：建议命令，但默认不自动执行
- `blocking`：是否阻断 Recon
- `last_known_good`：是否使用了最后一个可信工件

**多人共享**

地图要区分三层，不能全部直接放进 Git：

1. **知识源文件，应通过 Git 共享**

例如：

- PRD、需求、ADR、契约、验收标准
- IWE 管理的 Markdown
- `.iwe/config.toml`
- 稳定 ID 和显式 `implemented_by` 关系

这些是团队共同维护的 Source of Truth，应通过 PR 审查。

1. **标准地图工件，可以选择性通过 Git 共享**

```
governance/recon/document_map_artifact.json
governance/recon/code_map_artifact.json
```

适合提交的是体积受控、确定性生成、可审查的快照。必须记录：

```
source_revision: git:abc123
generated_by: codebase-memory-mcp@0.10.0
schema_version: "1.0"
```

1. **Provider 原生索引，不应通过 Git 共享**

例如：

- codebase-memory 的数据库、压缩图和缓存
- IWE 本地缓存
- 临时查询结果
- 机器相关路径和锁文件

这类文件通常体积大、不可稳定合并，应加入 `.gitignore`，由每个成员本地重建或由 CI 生成。

**冲突概率**

取决于地图提交方式：

| 方式                           | 冲突概率 |
| ------------------------------ | -------- |
| 每个人提交一个单体大 JSON 地图 | 高       |
| JSON 未固定排序、包含时间戳    | 很高     |
| 按需求/模块拆分工件            | 中低     |
| 只有 CI 负责刷新地图           | 低       |
| 不提交生成地图，只提交知识源   | 最低     |

Git 可以处理文本级冲突，但不能判断地图语义。例如两个分支都修改：

```
"implemented_by": [...]
```

Git 只能合并行，无法判断关系是否重复、失效或属于不同 revision。二进制数据库则基本无法合并。

**推荐工作流**

````
```mermaid
flowchart LR
  A["需求/代码变更"] --> PR["Git PR"]
  PR --> CI["CI 构建双地图"]
  CI --> V["校验稳定 ID / Revision / Schema"]
  V --> T["生成 Trace Link"]
  T --> M["生成确定性地图快照"]
  M --> R["PR 审查或构建制品"]
  R --> G["合并后团队拉取"]
  G --> L["本地 Recon 检查新鲜度"]
```
````

最佳实践是：

- 人提交需求源、代码和显式关系
- CI 基于 PR commit 统一生成地图
- 地图字段固定排序，剔除本机绝对路径
- `queried_at` 等易变字段放到 manifest，避免污染主地图
- 地图与 commit 强绑定
- 本地代码不是该 revision 时拒绝消费地图
- 地图冲突不手工合并，基于合并后的源码重新生成

如果用户没有 `git pull`，343 无法替用户获得远端知识。此时应明确提示：

```
LOCAL_REVISION_BEHIND_OR_UNKNOWN
建议先同步项目；当前地图只代表本地 revision，不保证包含团队最新需求。
```

结论是：

> Git 应同步“地图来源和稳定关系”，CI负责生成共享地图快照，原生索引由本地重建。Git 能传输地图，但不适合承担地图的语义合并。

这些规则应该补进尚未签署的 T-142，尤其增加“恢复建议”“Git/CI共享模型”和“确定性生成、避免多人提交单体地图”三个验收项。





Q: 这些规则应该补进尚未签署的 T-142；那是否意味着团队协作场景下，理想模式是 只有 CI 负责刷新地图 ；本地调用 343 recon 时候，是不应该重头生成map的？

A: 是的，团队协作的理想模式是：

> **CI 负责刷新权威标准地图，本地 Recon 默认只消费和校验，不从头重建共享地图。**

本地 Recon 的决策顺序应为：

1. CI 地图与本地 Git revision 匹配：直接使用。
2. 本地代码落后或 revision 不匹配：提示 `git pull` 或获取对应 CI 制品，不覆盖地图。
3. CI 地图缺失：可建立 `authority: local` 的临时地图，仅用于当前开发者。
4. Provider 不可用：按 L0/L1/L2 降级，并明确提示影响和修复操作。

需要区分：

- `authority: ci`：团队权威快照，本地不得覆盖。
- `authority: local`：本地临时增强，可随时重建，不应提交 Git。
- 单人项目：Recon 仍可直接生成项目标准地图。

相关规则已经补进 [T-142 契约](/Users/wanglijie/Downloads/Agentic-Agile-343/governance/contracts/Intent_Contract_T-142.md)，新增了故障诊断、CI 权威、本地回退、确定性快照和 L0-L3 注入验收项。