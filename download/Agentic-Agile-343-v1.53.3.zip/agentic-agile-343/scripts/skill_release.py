#!/usr/bin/env python3
"""Build and publish Agentic-Agile-343 from one validated staging tree."""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

from tool_bootstrap import prepare_ocusage


VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")
VERSION_FILES = ("SKILL.md", "README.md", "README.en.md", "RELEASE_NOTES.md", "RELEASE_NOTES.en.md")
PUBLIC_DOCUMENTS = ("RELEASE_NOTES.md", "RELEASE_NOTES.en.md", "LICENSE")
PUBLIC_READMES = ("README.md", "README.en.md")
PUBLIC_PRESERVE_DIRS = ("pic",)
PUBLIC_DOWNLOAD_DIR = "download"
PORTAL_RESOURCE_DIR = "resource"
PORTAL_ARCHIVE_NAME = "Agentic-Agile-343-latest.zip"
DEFAULT_EXCLUDES = {
    ".git", ".github", ".DS_Store", "__pycache__", "governance", "tests",
    "dist", ".pytest_cache", ".mypy_cache", ".coverage", ".workbuddy",
    ".codebase-memory",
}


def current_version(source: Path) -> str:
    match = re.search(r'^\s*version:\s*"(\d+\.\d+\.\d+)"\s*$',
                      (source / "SKILL.md").read_text(encoding="utf-8"), re.MULTILINE)
    if not match:
        raise ValueError("SKILL.md metadata version was not found")
    return match.group(1)


def validate_versions(source: Path, expected: str) -> list[str]:
    errors = []
    for name in VERSION_FILES:
        path = source / name
        if not path.is_file() or expected not in path.read_text(encoding="utf-8"):
            errors.append(f"{name} does not contain version {expected}")
    if current_version(source) != expected:
        errors.append(f"SKILL.md metadata version is not {expected}")
    return errors


def set_version(source: Path | str, version: str) -> dict:
    source = Path(source).resolve()
    if not VERSION_RE.fullmatch(version):
        raise ValueError(f"invalid semantic version: {version}")
    old = current_version(source)
    if old == version:
        errors = validate_versions(source, version)
        if errors:
            raise ValueError("; ".join(errors))
        return {"version": version, "updated": []}
    replacements = {
        "SKILL.md": [(rf'(?m)^(\s*version:\s*"){re.escape(old)}("\s*)$', rf'\g<1>{version}\g<2>')],
        "README.md": [(rf'(?m)^(# .* v){re.escape(old)}$', rf'\g<1>{version}')],
        "README.en.md": [(rf'(?m)^(# .* v){re.escape(old)}$', rf'\g<1>{version}')],
        "RELEASE_NOTES.md": [
            (rf'(?m)^(# .* v){re.escape(old)}$', rf'\g<1>{version}'),
            (rf'(?m)^(- \*\*版本\*\*：`){re.escape(old)}(`)$', rf'\g<1>{version}\g<2>'),
        ],
        "RELEASE_NOTES.en.md": [
            (rf'(?m)^(# .* v){re.escape(old)}$', rf'\g<1>{version}'),
            (rf'(?m)^(- \*\*Version\*\*: `){re.escape(old)}(`)$', rf'\g<1>{version}\g<2>'),
        ],
    }
    rendered_files = {}
    for name, rules in replacements.items():
        path = source / name
        rendered = path.read_text(encoding="utf-8")
        substitutions = 0
        for pattern, replacement in rules:
            rendered, count = re.subn(pattern, replacement, rendered)
            substitutions += count
        if substitutions != len(rules):
            raise ValueError(f"{name} normative version fields are inconsistent with {old}")
        rendered_files[path] = rendered
    for path in (source / "tests" / "test_windows_core_migration.py",
                 source / "tests" / "test_scope_v_control_planes.py"):
        if path.is_file():
            rendered_files[path] = path.read_text(encoding="utf-8").replace(old, version)
    originals = {path: path.read_text(encoding="utf-8") for path in rendered_files}
    try:
        for path, rendered in rendered_files.items():
            path.write_text(rendered, encoding="utf-8")
        errors = validate_versions(source, version)
        if errors:
            raise ValueError("; ".join(errors))
    except Exception:
        for path, original in originals.items():
            path.write_text(original, encoding="utf-8")
        raise
    return {"version": version, "updated": [str(path.relative_to(source)) for path in rendered_files]}


def _ignored(_directory: str, names: list[str], excludes: set[str]) -> set[str]:
    return {name for name in names if name in excludes or name.endswith((".pyc", ".zip"))}


def _tracked_files(source: Path) -> list[Path] | None:
    """Use the repository manifest when source is a Git worktree root."""
    root = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"], cwd=source,
        capture_output=True, text=True, shell=False,
    )
    if root.returncode != 0 or Path(root.stdout.strip()).resolve() != source:
        return None
    listed = subprocess.run(
        ["git", "ls-files", "-z"], cwd=source,
        capture_output=True, shell=False,
    )
    if listed.returncode != 0:
        return None
    return [Path(raw.decode("utf-8")) for raw in listed.stdout.split(b"\0") if raw]


def _excluded_path(path: Path, excludes: set[str]) -> bool:
    return any(part in excludes for part in path.parts) or path.name.endswith((".pyc", ".zip"))


def build_staging(source: Path | str, staging: Path | str,
                  excludes: set[str] | None = None) -> Path:
    source, staging = Path(source).resolve(), Path(staging).resolve()
    excludes = set(DEFAULT_EXCLUDES if excludes is None else excludes)
    staging.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=f".{staging.name}.", dir=staging.parent))
    shutil.rmtree(temporary)
    backup = staging.parent / f".{staging.name}.backup"
    try:
        tracked = _tracked_files(source)
        if tracked is None:
            shutil.copytree(source, temporary, ignore=lambda directory, names: _ignored(directory, names, excludes))
        else:
            temporary.mkdir()
            for relative in tracked:
                if _excluded_path(relative, excludes):
                    continue
                target = temporary / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source / relative, target)
        if backup.exists():
            shutil.rmtree(backup)
        if staging.exists():
            os.replace(staging, backup)
        os.replace(temporary, staging)
        if backup.exists():
            shutil.rmtree(backup)
    except Exception:
        if not staging.exists() and backup.exists():
            os.replace(backup, staging)
        raise
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    return staging


def atomic_install(staging: Path | str, install_dir: Path | str) -> Path:
    staging, install_dir = Path(staging).resolve(), Path(install_dir).expanduser().resolve()
    install_dir.parent.mkdir(parents=True, exist_ok=True)
    incoming = Path(tempfile.mkdtemp(prefix=f".{install_dir.name}.incoming.", dir=install_dir.parent))
    shutil.rmtree(incoming)
    backup = install_dir.parent / f".{install_dir.name}.backup"
    try:
        shutil.copytree(staging, incoming)
        if backup.exists():
            shutil.rmtree(backup)
        if install_dir.exists():
            os.replace(install_dir, backup)
        os.replace(incoming, install_dir)
        if backup.exists():
            shutil.rmtree(backup)
    except Exception:
        if not install_dir.exists() and backup.exists():
            os.replace(backup, install_dir)
        raise
    finally:
        if incoming.exists():
            shutil.rmtree(incoming)
    return install_dir


def build_zip(staging: Path | str, archive: Path | str) -> Path:
    staging, archive = Path(staging).resolve(), Path(archive).resolve()
    archive.parent.mkdir(parents=True, exist_ok=True)
    temporary = archive.with_name(f".{archive.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(staging.rglob("*")):
            if path.is_file():
                bundle.write(path, Path(staging.name) / path.relative_to(staging))
    with zipfile.ZipFile(temporary) as bundle:
        damaged = bundle.testzip()
        if damaged:
            raise ValueError(f"ZIP integrity check failed at {damaged}")
    os.replace(temporary, archive)
    return archive


def sync_public_release(source: Path | str, staging: Path | str,
                        public_dir: Path | str, archive_name: str) -> tuple[Path, Path]:
    """Make the public repository contain instructions and the release ZIP only.

    The repository's .git directory is preserved so this operation can be run
    from a checked-out public repository. All other existing entries are
    replaced from a temporary directory and restored if copying fails.
    """
    source, staging, public_dir = (Path(value).resolve() for value in (source, staging, public_dir))
    if Path(archive_name).name != archive_name or not archive_name.endswith(".zip"):
        raise ValueError("archive name must be a plain .zip filename")
    missing = [name for name in PUBLIC_DOCUMENTS if not (source / name).is_file()]
    if missing:
        raise ValueError("public documents are missing: " + ", ".join(missing))
    missing_readmes = [name for name in PUBLIC_READMES if not (public_dir / name).is_file()]
    if missing_readmes:
        raise ValueError("standalone public README is missing: " + ", ".join(missing_readmes))

    public_dir.parent.mkdir(parents=True, exist_ok=True)
    public_dir.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=f".{public_dir.name}.", dir=public_dir.parent))
    backup = Path(tempfile.mkdtemp(prefix=f".{public_dir.name}.backup.", dir=public_dir.parent))
    shutil.rmtree(backup)
    backup.mkdir()
    try:
        for name in PUBLIC_READMES:
            shutil.copy2(public_dir / name, temporary / name)
        for name in PUBLIC_PRESERVE_DIRS:
            preserved = public_dir / name
            if preserved.is_dir():
                shutil.copytree(preserved, temporary / name)
        for name in PUBLIC_DOCUMENTS:
            shutil.copy2(source / name, temporary / name)
        download_dir = temporary / PUBLIC_DOWNLOAD_DIR
        download_dir.mkdir()
        archive = build_zip(staging, download_dir / archive_name)

        if public_dir.exists():
            for child in public_dir.iterdir():
                if child.name == ".git":
                    continue
                os.replace(child, backup / child.name)
        for child in temporary.iterdir():
            os.replace(child, public_dir / child.name)
        shutil.rmtree(temporary)
        shutil.rmtree(backup)
    except Exception:
        for child in public_dir.iterdir() if public_dir.exists() else ():
            if child.name != ".git":
                shutil.rmtree(child) if child.is_dir() else child.unlink()
        if backup.exists():
            for child in backup.iterdir():
                os.replace(child, public_dir / child.name)
        raise
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
        if backup.exists():
            shutil.rmtree(backup)
    return public_dir, public_dir / PUBLIC_DOWNLOAD_DIR / archive_name


def sync_portal_resource(archive: Path | str, portal_dir: Path | str) -> Path:
    """Publish one stable, version-agnostic 343 download for the portal."""
    archive, portal_dir = Path(archive).resolve(), Path(portal_dir).resolve()
    if not archive.is_file():
        raise ValueError(f"release archive does not exist: {archive}")
    resource_dir = portal_dir / "public" / PORTAL_RESOURCE_DIR
    resource_dir.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".agentic-agile-343.", dir=resource_dir.parent))
    try:
        target = temporary / PORTAL_ARCHIVE_NAME
        shutil.copy2(archive, target)
        for existing in resource_dir.iterdir():
            if existing.is_file() and existing.name.lower().startswith("agentic-agile-343") and existing.suffix.lower() == ".zip":
                existing.unlink()
        legacy_dir = portal_dir / "public" / "resources"
        if legacy_dir.is_dir():
            for existing in legacy_dir.iterdir():
                if existing.is_file() and existing.name.lower().startswith("agentic-agile-343") and existing.suffix.lower() == ".zip":
                    existing.unlink()
        os.replace(target, resource_dir / PORTAL_ARCHIVE_NAME)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    return resource_dir / PORTAL_ARCHIVE_NAME


def default_publish_paths(source: Path, version: str) -> dict[str, str]:
    """Return the repository-local defaults used by the version shorthand."""
    return {
        "staging": str(Path(tempfile.gettempdir()) / "agentic-agile-343-release-staging" / "agentic-agile-343"),
        "install_dir": str(Path("~/.codex/skills/agentic-agile-343").expanduser()),
        "public_dir": str(source.parent / "Agentic-Agile-343"),
        "portal_dir": str(source.parent / "agentic-agile-portal"),
        "zip": f"Agentic-Agile-343-v{version}.zip",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", help="version to publish, or version/stage/publish")
    parser.add_argument("--source", default=".")
    parser.add_argument("--version")
    parser.add_argument("--staging")
    parser.add_argument("--install-dir")
    parser.add_argument("--public-dir")
    parser.add_argument("--portal-dir")
    parser.add_argument("--zip")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    if VERSION_RE.fullmatch(args.command):
        if args.version and args.version != args.command:
            raise SystemExit("positional version and --version disagree")
        args.version = args.command
        args.command = "publish"
    elif args.command not in ("version", "stage", "publish"):
        raise SystemExit("command must be version, stage, publish, or a semantic version")
    if args.version:
        set_version(source, args.version)
    version = current_version(source)
    errors = validate_versions(source, version)
    if errors:
        raise SystemExit("; ".join(errors))
    if args.command == "version":
        print(version)
        return 0
    if args.command == "publish":
        defaults = default_publish_paths(source, version)
        for name, value in defaults.items():
            if getattr(args, name) is None:
                setattr(args, name, value)
    if not args.staging:
        raise SystemExit("--staging is required")
    staging = build_staging(source, args.staging)
    if args.command == "stage":
        print(staging)
        return 0
    if not args.install_dir or not args.zip or not args.public_dir or not args.portal_dir:
        raise SystemExit("publish requires --install-dir, --public-dir, --portal-dir, and --zip")
    installed = atomic_install(staging, args.install_dir)
    tool = prepare_ocusage()
    requested_archive = Path(args.zip)
    public_dir = Path(args.public_dir)
    archive_name = requested_archive.name
    public_dir, archive = sync_public_release(source, staging, public_dir, archive_name)
    portal_archive = sync_portal_resource(archive, args.portal_dir)
    print(f"version={version}\nstaging={staging}\ninstalled={installed}\n"
          f"ocusage={tool['status']}\npublic_dir={public_dir}\nzip={archive}\n"
          f"portal_zip={portal_archive}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
